<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
th
{
	text-align:center;
}
a:link
{
	color:black;
	
}
</style>
</head>
<body>
<?php

include("head.php");
include("doc_menu.php");
include("doc_side.php");
echo"
<div class='col-md-9'>

";

if(isset($_REQUEST['act']))
{
	$act=$_REQUEST['act'];
	$sch_id=$_REQUEST['sch_id'];
	switch($act)
				{
					case 1:
						$sql2="delete from schedule where sch_id=$sch_id";
						$query2=mysql_query($sql2);
						if($query2)
						{
							header("Location:view_schedule.php");
						}
						else{
							echo "Error<br/>$sql2";
						}
							
					break;
				}
	
	
	
}



else if(isset($_POST['view']))
{
	$date=$_POST['date'];
	$sql="select * from schedule where date='$date'";
	$query=mysql_query($sql);
	
	
	$row_count=mysql_num_rows($query);
	if($row_count>0)
	{
		echo "<table border=1 width=50%>
	<tr><th rowspan='2'>Date</th><th rowspan='2'>Center</th><th colspan='2'>Time</th><th rowspan='2'>Delete</th></tr>
	<tr><th>From</th><th>To</th></tr>";
	
	while($row_data=mysql_fetch_array($query))
	{
		echo"<tr>			 
	<td>$row_data[1]</td>
	<td>$row_data[4]</td>
	<td>$row_data[2]</td>
	<td>$row_data[3]</td>
	<td><a href='view_schedule.php?act=1&sch_id=$row_data[5]'>Delete</a></td>
	</tr>";
	}
	echo "</table>";
	
	
}
else{ 
echo"Schedule not set for this date";
}
}

else{
echo"<form action='view_schedule.php' method='post'>
<table>
<tr><td>Enter Date</td>
<td><input type='date' name='date' required></td></tr>
<tr><td><input type='submit' name='view' value='View'></td></tr>
</table></form>
";
}


echo"</div></div></div>";
include("footer.php");

?>
</body>
</html>
