<?php 
//session_start();
include("connection.php");


if(isset($_POST['login']))
{
$user_id=$_POST['uid'];	
$password=$_POST['pwd'];


$sql="select * from user where user_id='$user_id' ";
$query=mysql_query($sql);
$row_data=mysql_fetch_row($query);
$row_count=mysql_num_rows($query);

if($row_count>0)
{
if($row_data[4]==$password)
{
	$_SESSION['user_id']=$user_id;
	header("Location:doc_profile.php");
	
}
else{
	
	echo "Incorrect Password";
}

}
else{
	
	echo "User not Found";
}
//echo "User id=$user_id";




}
else
{
	


echo "<form action='doc_login.php' method='post'>";
echo "<table>
<tr><td> <a href='doc_signup.php'>Not a user? SignUp. </a></td></tr>
<tr><td>User id</td><td><input type='text' name='uid' required/></td></tr>
<tr><td>password</td><td><input type='password' name='pwd' required/></td></tr>
<tr><td><input type='submit' name='login' value='Login'/></td>
<td><a href='doc_forgot.php'>Forgot Password?</a></td></tr>

</table>
";

echo "</form>";
}
		
?>
