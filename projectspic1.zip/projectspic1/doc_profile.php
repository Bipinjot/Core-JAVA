<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#a1 td
{
	padding:10px;
}
#a2
{
	padding: 60px;
	font-size:150%;
}
</style>

</head>
<body>
<?php
include("head.php");
include("doc_menu.php");
echo"<div class='container'><div class='row'>
";

$sql1="select * from user where user_id=$user_id";
$query1=mysql_query($sql1);
$row_data=mysql_fetch_row($query1);


echo"<div class='col-md-3'><img src='$row_data[14]' class='img-responsive'><br/>
<a href='change_image.php' id='a2'>Update Image </a>
</div><div class='col-md-1'></div>";

echo"
<div class='col-md-5'>
<table id='a1'>

<tr><td><b>First Name:</b></td><td>$row_data[1]</td></tr>
<tr><td><b>Last Name:</b></td><td>$row_data[2]</td></tr>
<tr><td><b>Gender:</b></td><td>$row_data[5]</td></tr>
<tr><td><b>D.O.B.:</b></td><td>$row_data[6]</td></tr>
<tr><td><b>Mobile Number:</b></td><td>$row_data[7]</td></tr>
<tr><td><b>Email:</b></td><td>$row_data[3]</td></tr>
<tr><td><b>Qualification:</b></td><td>$row_data[8]</td></tr>
<tr><td><b>Specification:</b></td><td>$row_data[9]</td></tr>
<tr><td><b>Address:</b></td><td>$row_data[10]</td></tr>
<tr><td><b>City:</b></td><td>$row_data[11]</td></tr>
<tr><td><b>State:</b></td><td>$row_data[12]</td></tr>
<tr><td><b>Pin Code:</b></td><td>$row_data[13]</td></tr>

</table>
";

echo"</div>";




echo"</div></div>";
include("footer.php");
?>
</body>
</html>