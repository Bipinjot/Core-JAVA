<!--<div class='row'>
<div class='col-md-12 menu'>
<table width=80%>
<tr>
<td style="padding-left:20px";><a href='index.php'>Home </a></td>
<td><a href='index.php#a1'>About Us </a></td>
<td><a href='index.php#a2'>Team </a></td>
<td><a href='index.php#a3'>Patient Education </a></td>
<td><a href='contact'> Contact Us </a></td>
<!-- <td><a href='demo.php'>Home </a></td> --
</tr>
</table>
</div> <!--end of col12--
</div> <!--end of row-->




<?php
echo"<nav class='navbar navbar-default'>
  
    
    <ul class='nav navbar-nav'>
      <li><a href='index.php'>Home</a></li>
      <li><a href='index.php#a1'>About Us</a></li>
      <li><a href='index.php#a2'>Team</a></li>
	  <li><a href='index.php#a3'>Patient Education</a></li>
    </ul>
    <ul class='nav navbar-nav navbar-right' style='padding-right:50px;'>
	
     
      <li><a href='index.php#a4'> Login</a></li>
	  <li><a href='contact.php'>Contact Us</a></li>
    </ul>
  
</nav>
  

";
?>


<!-- <meta charset="utf-8"> 
	// <meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" href="../dist/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="../dist/js/bootstrap.min.js"></script>
  </head>
  <body>
  <div class="container"> <!--container |container-fluid --> 
  
  <!--
 <nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <!--<div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Brand</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <!--<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav ">
        <li class="active"><a href='index.php'>Home <span class="sr-only">(current)</span></a></li>
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">One more separated link</a></li>
          </ul>
        </li>
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  <!--</div><!-- /.container-fluid -->
<!--</nav>
</div>
  </body>
</html>-->

<!--<nav class="navbar navbar-nav">
  
  
  
</nav>-->


<!--<head>
<link rel='stylesheet' href='style_menu.css'/>
</head>
<body>

<ul class='menu' >
  <li><a href='#' class='active'>Home</a></li>
  <li><a href='#'>About</a></li>
  <li><a href='#'>Portfolio</a></li>
  <li><a href='#'>Contact</a></li>
  <li class='slider'></li>
</ul>
</body>-->


<!--<head>
<style>
$responsive-menu-breakpoint: 1220px !default;

@mixin hide-menu {
	opacity: 0;
	pointer-events: none;
	margin-top: 20px;
	transition: 200ms all;

	position: absolute;
	top: 100%;
	left: 0;

	right: auto;

	min-width: 200px;
}

@mixin show-menu {
	opacity: 1;
	pointer-events: auto;
	margin-top: 0;
	
	z-index: 20;
}

.responsive-menu {
	position: relative;
}

.main-menu, .sub-menu {
	display: block;
	list-style: none;
	margin: 0;
	padding: 0;
	font-size: 0;
	
	li {
		font-size: 1rem;
	}
}

.main-menu {
	& > li {
		display: inline-block;
		position: relative;
		vertical-align: middle;
		
		a {
			display: block;
		}
		
		&.active {
			.sub-menu {
				@include show-menu;
			}
		}
		
		&:hover {
			@media only screen and (min-width: $responsive-menu-breakpoint + 1 ) {
				.sub-menu {
					@include show-menu;
				}
			}
		}
	}
	
	.expand {
		display: none;
	}
	
	@media only screen and (max-width: $responsive-menu-breakpoint) {
		@include hide-menu;
		
		width: 80%;
		left: 10%;
		
		li {
			display: block;
		}
		
		.expand {
			display: block;
			position: absolute;
			top: 0;
			right: 0;
			
			padding: 0.5rem 1rem;
			
			z-index: 15;
			
			transform-origin: 50%;
			transition: 200ms all;
			
			&.active {
				transform: rotate(45deg);
			}
		}
	}
	
	&.active {
			@media only screen and (max-width: $responsive-menu-breakpoint) {
			@include show-menu;			
		}
	}
}

.sub-menu {
	@include hide-menu;
	
	@media only screen and (max-width: $responsive-menu-breakpoint) {
		display: block;
		z-index: 20;
		width: 100%;
	}
	
	li {
		a {
			display: block;
		}
	}
}

// Responsive
.toggle-menu {
	display: none;
	
	@media only screen and (max-width: $responsive-menu-breakpoint) {
		display: inline-block;
	}
}

// Styling (not requred)
body {
	font-family: sans-serif;
}

header {
	background: #333333;
	font-size: 0;
}

nav {
	display: inline-block;
	vertical-align: middle;
	position: relative;
	background: #333333;
	
	font-size: 1rem;
	
	box-sizing: border-box;
	width: 85%;
	
	@media only screen and (min-width: $responsive-menu-breakpoint + 1 ) {
		text-align: right;
	}
}

.toggle-menu {
	color: #ffffff;
	padding-right: 1rem;
	float: right;
	
	span {
		display: inline-block;
		vertical-align: middle;
		padding-left: 0.3rem;
	}
	
	svg {
		display: inline-block;
		vertical-align: middle;
	}
}

.logo {
	display: inline-block;
	vertical-align: middle;
	color: #ffffff;
	font-size: 2rem;
	padding: 0.8rem 1rem;
	
	box-sizing: border-box;
	width: 15%;
}

.main-menu, .sub-menu {
	background: #333333;
	
	li {
		a {
			padding: 1rem 1rem;
			color: #ffffff;
			text-decoration: none;
		}
	}
	
	.expand {
		color: #ffffff;
		font-size: 1.5rem;
	}
}

.sub-menu {
	@media only screen and (max-width: $responsive-menu-breakpoint) {
		background: #777777;
	}
}
</style>


<script>
// Sub-menu
var submenus = document.querySelectorAll("ul.sub-menu");
if(submenus.length > 0) for(var i=0; i<submenus.length; i++) {
    var span = document.createElement('span');
    span.classList.add('expand');
    span.innerHTML = "+";

    span.addEventListener('click', function(){
        this.classList.toggle('active');
        // this.nextElementSibling.classList.toggle('active');
		  this.parentNode.classList.toggle('active');
    });
	
    submenus[i].previousElementSibling.appendChild(span);
    submenus[i].parentNode.insertBefore(span, submenus[i]);
}


/*
	<a class="anyclass" href="#" data-toggle-class="active, someotherclass" data-toggle-target=".menu, self">Menu</a>

	data-toggle-class - classes to apply to targets
	data-toggle-target - target's selectors to apply classes to

	If there is no 'data-toggle-target' attribute (only 'data-toggle-class'), classes are applyed to trigger element. 
	If classes are needed to be appled to targets including trigger element itself, use keywords 'this' or 'self'.
*/
(function() {

	function toggleClasses(classes, obj)
	{
		if(!classes) return;
		if(!obj) return;
		for(var n=0; n<classes.length; n++) obj.classList.toggle(classes[n].trim());
	}

	function applyToTargets(targetslist, dototargets, obj, dotoself, dotonext)
	{
		if(!targetslist) return;
		if(!dototargets) return;

		targetslist = targetslist.split(',');

		for(var n=0; n<targetslist.length; n++)
		{
			targetslist[n] = targetslist[n].trim();
			
			if( (targetslist[n] == 'this' || targetslist[n] == 'self') && obj && dotoself ) dotoself(obj);
			if(targetslist[n] == 'next' && obj && dotonext ) dotonext(obj.nextElementSibling);
			else 
			{
				var elems = document.querySelectorAll( targetslist[n] );
				if(elems.length > 0) 
				{
					for(var m=0; m<elems.length; m++) 
					{
						dototargets(elems[m]); 
					}
				}
			}
		}
	}

	var clickToggle = document.querySelectorAll('[data-toggle-class]');

	if(clickToggle.length > 0) 
	{
		for(var i=0; i<clickToggle.length; i++) 
		{
			clickToggle[i].addEventListener('click', function(e) {
				e.preventDefault();

				var classes = this.getAttribute('data-toggle-class');
				if(!classes) return;

				classes = classes.split(',');
				for(var n=0; n<classes.length; n++) classes[n] = classes[n].trim();

				var targets = this.getAttribute('data-toggle-target');

				if(!targets) toggleClasses(classes, this); //for(var n=0; n<classes.length; n++)  this.classList.toggle(classes[n]);
				else 
				{
					applyToTargets(targets, function(elem){ toggleClasses(classes, elem); }, this, function(elem){ toggleClasses(classes, elem); }, function(elem){ toggleClasses(classes, elem); });
				}
			});
		}
	}
})();
</script>

</head>

<body>
<header>
	<div class="logo">Logo</div>

<nav class="responsive-menu">
	<a href="#" class="toggle-menu" data-toggle-class="active" data-toggle-target=".main-menu, this"><svg height="32" viewBox="0 0 32 32" width="32" xmlns="http://www.w3.org/2000/svg"><path d="M4 10h24c1.104 0 2-.896 2-2s-.896-2-2-2H4c-1.104 0-2 .896-2 2s.896 2 2 2zm24 4H4c-1.104 0-2 .896-2 2s.896 2 2 2h24c1.104 0 2-.896 2-2s-.896-2-2-2zm0 8H4c-1.104 0-2 .896-2 2s.896 2 2 2h24c1.104 0 2-.896 2-2s-.896-2-2-2z" fill="#fff"/></svg><span>Menu</span></a>
	
    <ul class="main-menu">
        <li><a href="#"><span>Item 1</span></a> 
            <ul class="sub-menu">
                <li><a href="#"><span>Item 1.1</span></a></li>
                <li><a href="#"><span>Item 1.2</span></a></li>
                <li><a href="#"><span>Item 1.3</span></a></li>
            </ul>
        </li>
        <li><a href="#"><span>Item 2</span></a>
            <ul class="sub-menu">
                <li><a href="#"><span>Item 2.1</span></a></li>
                <li><a href="#"><span>Item 2.2</span></a></li>
                <li><a href="#"><span>Item 2.3</span></a></li>
                <li><a href="#"><span>Item 2.4</span></a></li>
            </ul>
        </li>
        <li><a href="#"><span>Item 3</span></a></li>
        <li><a href="#"><span>Item 4</span></a></li>
        <li><a href="#"><span>Item 5</span></a></li>
        <li><a href="#"><span>Item 6</span></a></li>
    </ul>
</nav>
	
</header>
</body> -->


