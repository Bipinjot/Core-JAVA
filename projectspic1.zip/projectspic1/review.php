<?php

include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#e1 td,th
{
	padding:30px;
}
</style>
</head>

<body>


<?php
echo"<p class='about'>Reviews</p>";



$sql="select * from contact";
$query=mysql_query($sql);

$row_count=mysql_num_rows($query);
if($row_count>0)
{
	echo
	"
	<table id='e1'>
	<tr>
	<th>Name</th>
	<th>Review</th>
	<th>Email</th?
	</tr>
	";
	
	while($row_data=mysql_fetch_array($query))
	{
		echo
		"<tr>
		 <td>$row_data[1]</td>
		 <td>$row_data[4]</td>
		 <td>$row_data[2]</td>
		 </tr>";
	}
	echo "</table>";
}

else
{
	echo "not found</br>
		 Go to <a href='index.php'>Home</a>";
}











 ?>

</body>
</html>