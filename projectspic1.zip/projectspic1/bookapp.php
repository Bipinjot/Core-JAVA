<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
</head>

<body>
<?php
include("head.php");
//include("menu.php");
include("pat_menu.php");
include("pat_side.php");
?>

<?php

echo"<h1>Book an appointment</h1>";

	
	if(isset($_REQUEST['time']))
	{
		
		$pat_id=$_REQUEST['pat_id'];
		$date=$_REQUEST['date'];
		$app_time=$_REQUEST['time'];
		$loc=$_REQUEST['location'];
		
		$sql1="select * from book_app where  pat_id=$pat_id";
		$query1=mysql_query($sql1);
		$row_data1=mysql_fetch_row($query1);
		

		$sql="insert into book_app (user_id,pat_id,date,time,location)values ($user_id,$pat_id,'$date','$app_time','$loc')";
		$query=mysql_query($sql);
		if($query)
		{
			echo "your appointment has been booked<br>Appointment Id:$row_data[0]";
		}
		else
		{
			echo "not booked";
		}
	}
		
	



include("footer.php");
	 
	
 ?>

</body>
</html>