<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#e1 td
{
	padding:10px;
}
</style>
</head>

<body>
<?php
include("head.php");
//include("menu.php");
include("pat_menu.php");
include("pat_side.php");
?>

<?php

echo"
<h1>Book an appointment</h1>";

$pat_id=$user_id;
if (isset($_POST['save']))
{
	$doc_id=$_POST['doc_id'];
	$sql1="SELECT checkup_time FROM user WHERE user_id=$doc_id";

	$query1=mysql_query($sql1);
	$row_data1=mysql_fetch_row($query1);
	$checkup_time=$row_data1[0];
		
		
	$date=$_POST['date'];
	$sql="select * from schedule where user_id='$doc_id' and date='$date'"; 
	$query=mysql_query($sql);
	$row_count=mysql_num_rows($query);
	
	//echo $row_count;
	echo "</br>";
	
	echo "Checkup_time:$checkup_time<hr/>";
		if($row_count>0)
		{
			while($row_data=mysql_fetch_row($query))
			{
			//$row_data=mysql_fetch_row($query);
			//print_r($row_data);
			
			$from_time=$row_data[2];
			$to_time=$row_data[3];
			$loc=$row_data[4];
			for($i=$from_time;$i<$to_time; $i++)
			{
					for($m=0;$m<60;$m +=$checkup_time)
					{						
							if($m==0)
							{
							$app_time=$i .":00";
							
						$sql="select time from book_app where user_id='$user_id' and date='$date' and time='$app_time' ";
						$query=mysql_query($sql);
						$row_count=mysql_num_rows($query);
						if($row_count!=0){$status="Booked";
						
						echo "$app_time  $status<br/>";
							 
						}else 
						{
						echo "<a href='bookapp.php?pat_id=$pat_id&date=$date&time=$app_time&location=$loc'>$app_time </a> <br/>";
							 
						}
							 //echo "Location:$row_data[4]</br>";
							//	echo "<a href='bookapp.php?pat_id=$pat_id&date=$date&time=$app_time&location=$loc'>$app_time </a> $status<br/>";
							 
							}
							
							else
							{
							$app_time=$i .":".$m;
							
						$sql="select time from book_app where user_id='$user_id' and date='$date' and time='$app_time' ";
						$query=mysql_query($sql);
						$row_count=mysql_num_rows($query);
						if($row_count!=0){$status="Booked";
						echo "$app_time $status<br/>";
						
						}else {
							$status="";
						echo "<a href='bookapp.php?pat_id=$pat_id&date=$date&time=$app_time&location=$loc'>$app_time</a> <br/>";
							
							}
		
							}
	/*					}
							else
							{
								echo "booked";
							}*/
					}
			}
			}
			
		}
		
		else
		{
			echo "not found";
		}
	
	
	
}


			else
			{	
								$sql1="select * from user";
								
						echo "<form method='Post' action='app.php'>
						<table id='e1'>
								<tr><td>Select Date</td><td><input type='date' name='date'></td></tr>
								<tr><td>Select Doctor</td><td><select name='doc_id'>";
								
								$query1=mysql_query($sql1);
								while($row_data=mysql_fetch_array($query1))
								{
									echo"<option value='$row_data[0]'>$row_data[1] $row_data[2]</option>";	
									
															
								}
								echo" </td></tr>";
								
								
								
								echo" </td></tr>	
								
								
								<tr><td>Submit</td><td><input type='submit' name='save' value='Click here'/></td><tr>
								
								
								
						</table>
						</form>";
}
	

	 
	 include("footer.php");
 ?>

</body>
</html>