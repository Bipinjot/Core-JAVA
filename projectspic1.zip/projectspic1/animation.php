<div class='row'>
		<div class='col-md-12'>
		<div class='well well-lg pic'>
		<div class='row img'></div>
		<div class='row trans'>
		<div class='col-md-9'>
		<h1><b>Looking for a Unique Gift?</b></h1><br>
<span style='font-size:25px'>You're in the right place!</span>
</div>
<div class='col-md-3'>
<div class='row bt_trans'>
</div>
<div class='row'>
<input type='button' class='btn btn-danger' value='Shop Now'/>
</div>
</div>
		</div>
		</div></div>
		</div>