<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<style>
a:link
{
	text-decoration:none;
	color:black;
}
#a2 td
{
	padding:6px;
	
}
</style>
<?php
include("script.php");
?>
</head>
<body>
<?php

include("head.php");
include("doc_menu.php");
include("doc_side.php");
echo"
<div class='col-md-9'>

";

if (isset($_POST['submit']))
{
	$name=$_POST['name'];
	$add=$_POST['address'];
	$num=$_POST['number'];
	
	$sql="insert into center(name,address,number) values('$name','$add','$num')";
	
	$query=mysql_query($sql);
if($query)
{
$auto_id=mysql_insert_id();	
	echo "<table id='a2'><tr><td>Added</td><td>
	<a href='schedule.php'><input type='button' value='Back'>
	</a></td></tr></table>";
}
else
{
	echo "error<br/>$sql";
}
}


echo"
<form action='new_center.php' method='post'>
<table id='a2'>
<tr><td>Center Name </td>
<td><input type='text' name='name' required></td></tr>
<tr><td>Center Address</td>
<td><input type='text' name='address' required></td></tr>
<tr><td>Contact Number</td>
<td><input type='text' name='number' required></td></tr>
<tr><td><input type='submit' name='submit' value='Submit'></td>
<td><a href='schedule.php'><input type='button' value='Cancel'></a></td></tr>
</table>
</form>
";

echo"</div></div></div>";
include("footer.php");

?>
</body>
</html>
