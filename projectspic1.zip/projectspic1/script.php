<link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'/>
<link rel='stylesheet' href='bootstrap/js/bootstrap.min.js'/>
<link rel='stylesheet' href='style.css'/>
<link rel='stylesheet' href='style_log.css'/>
<script src='bootstrap/js/bootstrap.min.js'></script>
<script src='bootstrap/js/jquery.min.js'></script>
<script src='jquery.js'></script>
<script src='jquery.validate.min.js'></script>