<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#e1 td
{
	padding:10px;
}
</style>
</head>

<body>
<?php
include("head.php");
//include("menu.php");
include("doc_menu.php");
include("doc_side.php");
?>

<?php

echo"
<h1>View Appointments</h1>";

if (isset($_POST['save']))
{
$date=$_POST['date'];
$sql="select * from book_app where date='$date'";
$query=mysql_query($sql);
$row_count=mysql_num_rows($query);
	if($row_count>0)
	{
		echo
		"
			<table width=50% border=1 id='e1'>
			<tr>
			<th>Appointment Id</th>
			<th>Patient Id</th>
			<th>Patient Name</th>
			<th>Date</th>
			<th>Time</th>
			<th>Location</th>
			</tr>
		";
		
		while($row_data=mysql_fetch_array($query))
		{
			echo"
				<tr>
				<td>$row_data[0]</td>
				<td>$row_data[2]</td>";
				$sql1="select * from patient where user_id=$row_data[2]";
				$query1=mysql_query($sql1);
				$row_data1=mysql_fetch_row($query1);
				
				echo"<td>$row_data1[1] $row_data1[2]</td>
				<td>$row_data[3]</td>
				<td>$row_data[4]</td>
				<td>$row_data[5]</td>
				</tr>
				";
		}
		
		echo "</table>";
	}

	else
	{
		echo "<a href='viewapp.php'>Back</a><br/>";
		echo "not Found";
						
	}	
		
}
else
{
			echo
			"
				<form action='viewapp.php' method='post'>
				<table id='e1'>
				
				<tr><td>Enter date</td><td><input type='date' name='date'></td></tr>
				<tr><td>Find appointments</td><td><input type='submit' name='save' value='Submit'></td></tr>
				</table>
				</form>
			
			";
}
	
	include("footer.php");

	 

?>


</body>
</html>