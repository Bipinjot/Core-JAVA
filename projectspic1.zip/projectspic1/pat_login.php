<?php 
session_start();


if(isset($_POST['login']))
{
$user_id=$_POST['uid'];	
$password=$_POST['pwd'];


$sql="select * from patient where user_id='$user_id' ";
$query=mysql_query($sql);
$row_data=mysql_fetch_row($query);
$row_count=mysql_num_rows($query);

if($row_count>0)
{
if($row_data[7]==$password)
{
	$_SESSION['user_id']=$user_id;
	header("Location:pat_profile.php");
	
}
else{
	
	echo "Incorrect Password";
}

}
else{
	
	echo "User not Found";
}
//echo "User id=$user_id";




}
else
{
	


echo "<form action='pat_login.php' method='post' onsubmit=' return  frm_check()'>";
echo "<table>
<tr><td> <a href='pat_signup.php'>Not a user? SignUp. </a></td></tr>
<tr><td>User id <span id='email_span'>*</span></td><td><input type='text' name='uid' onkeyup='error_check(/'email/',/'email_span/',2)'/>
</td></tr>
<tr><td>Password <span id='pwd_span'>*</span></td><td><input type='password' name='pwd' onkeyup='error_check(this.id,/'pwd_span',1)'/>
</td></tr>
<tr><td><input type='submit' name='login' value='Login'/></td>
<td><a href='pat_forgot.php'>Forgot Password?</a></td></tr>
</table>
";

echo "</form>";
}
	

?>
