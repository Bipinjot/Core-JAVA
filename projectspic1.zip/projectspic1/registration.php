<?php
	
	include ("connection.php");
	?>
	<html>
	<head>
	<?php
	include ("script.php");
	?>
	<!-- <style>
span
{
color:black;

visibility:hidden;
}
</style>
<script>
var regx=/\S/;   //var isNonblank_re    
var regx1=/^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;   //var isEmail_re 
function empty_check(cnt_id)
{
var cnt_value=document.getElementById(cnt_id).value;
//if(cnt_value=="")
if(!cnt_value.match(regx))
//if(cnt_value.trim().length==0)
{
alert("Empty error");
}
}
function empty_check1(cnt_id,span_id)
{
var cnt_value=document.getElementById(cnt_id).value;
var regx=/\S/;
if(!cnt_value.match(regx))
{
document.getElementById(span_id).style.visibility="visible";
}
else
{
document.getElementById(span_id).style.visibility="hidden";
}
}
function error_check(cnt_id,span_id,err_no) 
{
var cnt_value=document.getElementById(cnt_id).value;
switch(err_no)
{
case 1:reg=regx;break;
case 2:reg=regx1; break;
}
if(!cnt_value.match(reg))
{
document.getElementById(span_id).style.visibility="visible";

}
else
{
document.getElementById(span_id).style.visibility="hidden";
}
}
function error_check1(cnt_id,span_id,err_no)
{
var cnt_value=document.getElementById(cnt_id).value;
switch(err_no)
{
case 1:reg=regx;break;
case 2:reg=regx1; break;
}
if(!cnt_value.match(reg))
{
document.getElementById(span_id).style.visibility="visible";
return false;
}
else
{
document.getElementById(span_id).style.visibility="hidden";
return true;
}
}
function frm_check()
{
var flag1=error_check1('email','email_span',2);
var flag2=error_check1('pwd','pwd_span',1);
if(flag1==true && flag2==true)
{
return true;
}
else{
return false;
}
}
</script> -->
	</head>
	<body>
	<?php
	include ("head.php");
	include ("menu.php");
?>

<div class='row'>
		<div class='col-md-12'>
		<div class='panel'>
		<div class='panel-body'> 
		

<h2><center>Signup Form</h2>
		<form method='post' action='registration.php' enctype="Multiple/form-data">
		<table align='center'>
		
			<tr><td><b>Firstname</b></td>
			  <td><input type="text" placeholder="Enter Firstname" name="fname" required></td></tr>
			<tr><td><b>Lastname</b></td>
			  <td><input type="text" placeholder="Enter Lastname" name="lname" required></td></tr>
			<tr><td><b>Email</b></td>
			  <td><input type="text" id='email' placeholder="Enter Email" onkeyup="error_check('email','email_span',2)">
				<span id='email_span'>Please fill correct email id**</span></td></tr>
			<tr><td><b>Password</b></td>
			  <td><input type="password" id='pwd'  placeholder="Enter password" onkeyup="error_check(this.id,'pwd_span',1)"/>
				<span id='pwd_span'>*</span></td>
			
			<tr><td><b>Repeat Password</b></td>
			  <td><input type="password" placeholder="Repeat Password" name="psw-repeat" required></td></tr>
			<tr><td><b>Gender</b></td>
			  <td><input type='radio' name='gen' value='male' checked>Male
					<input type='radio' name='gen' value='female'>Female</td></tr>
			<tr><td><b>D.O.B</b></td>
			  <td><input type="date"  required></td></tr>
			<tr><td><b>Mobile No.</b></td>
			  <td><input type="text" placeholder="Enter Mobileno." name="mob" maxlength=10 required></td></tr>
			<tr><td><b>Qualification</b></td>
			  
			  <td><select required>
				<option selected>--SELECT ONE--</option>
				<option>B.D.S</option>
				<option>B.H.M.S</option>
				<option>B.P.T</option>
				<option>B.U.M.S</option>
				<option>M.B.B.S</option>
				<option>MD</option>
				<option>MS</option>
				<option>MDS</option>
			</select></td></tr>
			
			<tr><td><b>Speciality</b></td>
			<td><select required >
			  <option selected>--SELECT ONE--</option>
				<option>Abdominal Radiology Radiology-Diagnostic</option>
				<option>Addiction Psychiatry Psychiatry</option>
				<option>Adolescent Medicine Pediatrics</option>
				<option>Allergy & Immunology</option>
				<option>Anesthesiology</option>
				<option>Cardiothoracic Radiology Radiology-Diagnostic</option>
				<option>Cardiovascular Disease Internal Medicine</option>
				<option>Chemical Pathology Pathology-Anatomic & Clinical</option>
				<option>Dermatology</option>
				<option>Dermatopathology </option>
				<option>Endocrinology, Diabetes & Metabolism Internal Medicine</option>
				<option>Endovascular Surgical Neuroradiology </option>
				<option>Gastroenterology Internal Medicine</option>
				<option>Geriatric Medicine Family Medicine</option>
			</select></td></tr>
			<tr><td><b>Address</b></td>
			  <td><input type="text" placeholder="Lane 1 " name="add" required></td></tr>
			<tr><td><b>City</b></td>
			  <td><input type="text" placeholder="Enter City " name="city" required> </td></tr>
			<tr><td><b>State</b></td>
			  <td><input type="text" placeholder="Enter State " name="state" required>  </td></tr> 
			<tr><td><b>Pincode</b></td>
			  <td><input type="text" placeholder="Enter Pincode " name="Pin" required></td></tr>  
			<tr><td><b>Upload Image</b></td>
			  <td><input type="file"  required> </td>
			<tr><td colspan=2><input type="checkbox" checked="checked"> Remember me</td></tr>
			<tr><td colspan=4><p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p></td></tr> 
		<tr><td colspan=4><input type='submit' value='Submit' id='submit' name='submit'></td></tr>
		
		
		</table>
		</form>
		</div>
		</div></div>
		</div>
		</body>
		</html>
		
		