<?php
//include("user_info.php");
?>
<head>
<style>
#a1 td
{
	padding:10px;
}
</style>
</head>
<?php
echo"<div class='container'>
<div class='row'>
<div class='col-md-3'>
";



$sql="select * from user where user_id=$user_id";
//echo"$sql";
	$query=mysql_query($sql);
	
$row_data=mysql_fetch_row($query);

echo"
<table id='a1'>
<tr><td colspan='3'><img src='$row_data[14]' class='img-responsive'</td></tr>
<tr><td>Name: $row_data[1]  $row_data[2]</td></tr>
<tr><td>D.O.B.: $row_data[6]</td></tr>
<tr><td>Email: $row_data[3]</td></tr>
<tr><td>Mobile No.: $row_data[7]</td></tr>

</table>";

echo"</div>";
?>