<!--<div class='row'>
<div class='col-md-12 menu'>
<table width=80%>
<tr>
<td style="padding-left:20px";><a href='pat_profile.php'>Profile </a></td>
<td><a href='submit_report.php'>Submit Reports </a></td>
<td><a href='pat_view_schedule.php'>View Doctor's Schedule</a></td>
<td><a href='bookapp.php'> Book an appointment</a></td>
<!--<td><a href='search_pat.php'>Search Patient</a></td>--
<td><a href='logout.php'> Logout </a></td>
<!-- <td><a href='demo.php'>Home </a></td> --
</tr>
</table>
</div> <!--end of col12--
</div> <!--end of row-->




<?php
echo"<nav class='navbar navbar-default'>
  
    
    <ul class='nav navbar-nav'>
      <li><a href='pat_profile.php'>Profile</a></li>
      <li><a href='pat_view_schedule.php'>View Doctor's Schedule</a></li>
      <li><a href='app.php'>Book an appointment</a></li>
	  <li><a href='submit_report.php'>Submit Reports</a></li>
    </ul>
    <ul class='nav navbar-nav navbar-right' style='padding-right:50px;'>
	
     
	  <li><a href='logout.php'>Logout</a></li>
    </ul>
  
</nav>
  

";
?>