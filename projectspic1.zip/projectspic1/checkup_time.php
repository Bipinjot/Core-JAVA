<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>

</head>
<body>
<?php

include("head.php");
include("doc_menu.php");
include("doc_side.php");
echo"<div class='col-md-9'>

";


if(isset($_POST['set']))
{
	$time=$_POST['ctime'];
	$sql="update user set checkup_time='$time' where user_id=$user_id";
	$query=mysql_query($sql);
	if ($query)
	{
	
	}
	else
	{
		echo"Error";
	}
}
$sql1="select * from user where user_id=$user_id";
$query1=mysql_query($sql1);
$row_data1=mysql_fetch_row($query1);


echo"
<form action='checkup_time.php' method='post'>
<table>
<tr><td>Checkup Time: $row_data1[17] mins</td></tr>
<tr><td>Set Time</td>
<td><select name='ctime'>
<option>10</option>
<option>15</option>
<option>20</option>
<option>30</option>

</select></td></tr>
<tr><td><input type='submit' value='Set' name='set'></td></tr>


</table>
</form>
";


echo"</div></div></div>";
include("footer.php");

?>
</body>
</html>