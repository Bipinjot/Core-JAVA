


$(document).ready( function()
	{
		$('#myform').validate
			(
				{
					rules:
						{
							fname:
								{
									required:true,
								   accept: "[a-zA-Z]+"
								},
								
								lname:
								{
									required:true,
								   accept: "[a-zA-Z]+"
								},
								
							email:
								{
								     required:true,
									 email:true
								 },
								 
							pwd:
								{
									required:true,
									minlength: 5
								},
								
							con_pwd:
							{
							required:true,
							minlength: 5,
							equalTo:"#pwd"
							},
							
							gen:
							{
								required:true,
							}
							dob:
								 {
								 required:true,
								 date:true
								 },

						}
				}
			);
	}
);

