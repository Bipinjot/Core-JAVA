<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Project</title>
<?php
include ("script.php");
?>
<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
	  height:400px;
  }
  
  #b1 td
  {
	  padding:10px;
  }
  </style>
</head>
<body>
<div class='container-fluid'>
<?php
include("head.php");
include("menu.php");
//include("animation.php");

//echo"<div class='row'>
//<div class='col-md-12 animation'>";
?>



<div class='row'>
		<div class='col-md-12'>
		<div class='well well-lg pic'>
		<div class='row img'></div>
		<div class='row trans'>
		<div class='col-md-9'>
		<h1><b>Aarogya Heart Foundation</b></h1><br>
<h2>You're in the right place!</h2>
</div>
</div>
		</div></div>
		</div>


<!-- 
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators --
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides --
    <div class="carousel-inner" role="listbox">

      <div class="item active">
        <img src="images/img1111.jpg" alt="Chania" width="460" height="345">
        <div class="carousel-caption">
          <h3>Chania</h3>
          <p>The atmosphere in Chania has a touch of Florence and Venice.</p>
        </div>
      </div>

      <div class="item">
        <img src="images/img3.jpg" alt="Chania" width="460" height="345">
        <div class="carousel-caption">
          <h3>Chania</h3>
          <p>The atmosphere in Chania has a touch of Florence and Venice.</p>
        </div>
      </div>
    
      <div class="item">
        <img src="images/img4.jpg" alt="Flower" width="460" height="345">
        <div class="carousel-caption">
          <h3>Flowers</h3>
          <p>Beautiful flowers in Kolymbari, Crete.</p>
        </div>
      </div>

      <div class="item">
        <img src="images/img5.jpg" alt="Flower" width="460" height="345">
        <div class="carousel-caption">
          <h3>Flowers</h3>
          <p>Beautiful flowers in Kolymbari, Crete.</p>
        </div>
      </div>
  
    </div>

    <!-- Left and right controls --
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

<br/>-->

<?php
echo"</div> <!--end of col12-->
</div> <br/><!--end of row-->";

echo"
<div class='row' id='a1'>
<div class='col-md-8 aboutus'>
<p class='about'><b>About Us</b></p><br>
<div class='row'><div class='col-md-6'>
<table>
<tr><td style='border-right: 1px solid; padding:10px;'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a 
galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
but also the leap into electronic typesetting, remaining essentially unchanged. 
It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, 
and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></td></tr>
</table></div>
<div class='col-md-6'><table><tr><td style='padding:10px;'><p>
It is a long established fact that a reader will be distracted by the readable 
content of a page when looking at its layout. The point of using Lorem Ipsum is 
that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, 
content here', making it look like readable English. Many desktop publishing packages 
and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' 
will uncover many web sites still in their infancy. Various versions have evolved over the years, 
sometimes by accident, sometimes on purpose (injected humour and the like).</p>


<a href='aboutus.php'>Read more</a></td></tr></table>
</div></div></div> <!--end of col8-->
<div class='col-md-4 centers'>
<p class='center'><b>Centers</b></p>
<ul>
<li>abcd</li>
<li>qwerty</li>
<li>wxyz</li>
<li>poiuy</li>
<li>khjals</li>
<li>abcde</li>
</ul>
</div>
</div> <!--end of row-->
";


echo"<div class='row' id='a2'>
<div class='col-md-12 team'>
<p class='about'>Our Team</p>
<div class='container'>
<div class='row'>
		<div class='col-md-4'>
		<div class='well well-md pic_3'>
		<img src='images/img2.jpg'><br>
		DoCTOR SHASHI JINDAL<br>
		<b>Consultant Cardiac Surgeon</b><br/>
		MBBS MS McH.
		</div>
		</div>
		<div class='col-md-4'>
		<div class='well well-md pic_3'>
		<img src='images/img6.jpg'><br>
		DoCTOR SHASHI JINDAL<br>
		<b>Consultant Cardiac Surgeon</b><br/>
		MBBS MS McH.
		</div>
		</div>
		<div class='col-md-4'>
		<div class='well well-md pic_3'>
		<img src='images/img4.jpg'><br>
		DoCTOR SHASHI JINDAL<br>
		<b>Consultant Cardiac Surgeon</b><br/>
		MBBS MS McH.
		</div>
		</div>
		</div>
</div>

<a href='team.php'>

</a>
</div>
</div>";


echo " <br/><div class='row' id='a4'>
<div class='col-md-6'>";
echo "<div class='panel panel-info min_h'>
			<div class='panel-heading'>Patient LogIn</div>
			<div class='panel-body'>";

			if(isset($_REQUEST['act'])  && $_REQUEST['act']==1)
			{
				//echo "case 1";
				
				
				
if(isset($_POST['login']))
{
$user_id=$_POST['uid'];	
$password=$_POST['pwd'];


$sql="select * from patient where user_id='$user_id' ";
$query=mysql_query($sql);
$row_data=mysql_fetch_row($query);
$row_count=mysql_num_rows($query);

if($row_count>0)
{
if($row_data[7]==$password)
{
	$_SESSION['user_id']=$user_id;
	header("Location:pat_profile.php");
	
}
else{
	
	echo "Incorrect Password";
}

}
else{
	
	echo "User not Found";
}
			}
			}
echo "<form action='index.php?act=1' method='post' onsubmit=' return  frm_check()'>";
echo "<table id='b1'>
<tr><td> <a href='pat_signup.php'>Not a user? SignUp. </a></td></tr>
<tr><td>User id <span id='email_span'>*</span></td><td><input type='text' name='uid' onkeyup='error_check(/'email/',/'email_span/',2)'/>
</td></tr>
<tr><td>Password <span id='pwd_span'>*</span></td><td><input type='password' name='pwd' onkeyup='error_check(this.id,/'pwd_span',1)'/>
</td></tr>
<tr><td><input type='submit' name='login' value='Login'/></td>
<td><a href='forget.php?case=1'>Forgot Password?</a></td></tr>
</table>
";

echo "</form>";

			echo"</div></div>";	
echo"</div>
<div class='col-md-6'>";
echo"<div class='panel panel-info min_h'>
			<div class='panel-heading'>Doctor LogIn</div>
			<div class='panel-body'>";

			if(isset($_REQUEST['act'])  && $_REQUEST['act']==2)
			{
				//echo "case 2";
				
				if(isset($_POST['login']))
{
$user_id=$_POST['uid'];	
$password=$_POST['pwd'];


$sql="select * from user where user_id='$user_id' ";
$query=mysql_query($sql);
$row_data=mysql_fetch_row($query);
$row_count=mysql_num_rows($query);

if($row_count>0)
{
if($row_data[4]==$password)
{
	$_SESSION['user_id']=$user_id;
	header("Location:doc_profile.php");
	
}
else{
	
	echo "Incorrect Password";
}

}
else{
	
	echo "User not Found";
}
//echo "User id=$user_id";




}
				
			}
echo "<form action='index.php?act=2' method='post'>";
echo "<table id='b1'>
<tr><td> <a href='doc_signup.php'>Not a user? SignUp. </a></td></tr>
<tr><td>User id</td><td><input type='text' name='uid' required/></td></tr>
<tr><td>password</td><td><input type='password' name='pwd' required/></td></tr>
<tr><td><input type='submit' name='login' value='Login'/></td>
<td><a href='forget.php?case=2'>Forgot Password?</a></td></tr>

</table>
";

echo "</form>";

echo"</div></div>";
echo"</div>
</div>";




echo"<div class='row' id='a3'>
<div class='col-md-12 edu'>
<p class='about'>Patient Education</p>
Contrary to popular belief, Lorem Ipsum is not simply random text.
 It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. 
 Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words,
 consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, 
 discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of 'de Finibus Bonorum et Malorum'
 (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, 
 very popular during the Renaissance. The first line of Lorem Ipsum, 'Lorem ipsum dolor sit amet..', comes from a line in section 1.10.32.
The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.
 Sections 1.10.32 and 1.10.33 from 'de Finibus Bonorum et Malorum' by Cicero are also reproduced in their exact 
 original form, accompanied by English versions from the 1914 translation by H. Rackham.
 <br>
 <h4><a>Get Details</a></h4>
</div>
</div>";


?>
<!--<div class='row'>
<div class='col-md-12 feed'>
<p class='about'>
Reviews</p>
</div> <!--end of col8--

</div> <!--end of row-->

<?php
include("review.php");
include("footer.php");
?>
</div> <!--end of container-->


</body>
</html>

