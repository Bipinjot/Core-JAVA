<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#e1 td
{
	padding:10px;
	text-align:centre;
}
</style>
</head>

<body>
<?php
include("head.php");
include("doc_menu.php");
//include("pat_menu.php");
?>
<div class='container'>
<?php
echo"
<h1>QUERIES</h2>
<div class='panel body'>";


$sql="select * from contact";
$query=mysql_query($sql);

$row_count=mysql_num_rows($query);
if($row_count>0)
{
	echo
	"
	<table id='e1' width=50% border=1>
	<tr>
	<th>Review Id</th>
	<th>Name</th>
	<th>Query</th>
	</tr>
	";
	
	while($row_data=mysql_fetch_array($query))
	{
		echo
		"<tr>
		 <td>$row_data[0]</td>
		 <td>$row_data[1]</td>
		 <td>$row_data[3]</td>
		 </tr>";
	}
	echo "</table>";
}

else
{
	echo "not found</br>
		 Go to <a href='index.php'>Home</a>";
}









echo"</div>";
include("footer.php");
 ?>
</div>
</body>
</html>