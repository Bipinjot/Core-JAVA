<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
</head>
<body>
<?php
include("head.php");
include("pat_menu.php");
include("pat_side.php");
echo"<div class='col-md-9'>";
if(isset($_POST['submit']))
{
	$image=$_FILES['report'];
	$image_name=$image['name'];
	$image_url=$image['tmp_name'];
	$date=$_POST['date'];
	$text=$_POST['text'];
	
	$sql1="insert into report(user_id,date,title) values($user_id,'$date','$text')";
	$query1=mysql_query($sql1);
	if($query1)
	{
		$auto_id=mysql_insert_id();
		$image_info=explode(".",$image_name);
		$len=count($image_info);
		$path="report/$user_id.$auto_id".".".$image_info[$len-1];
		move_uploaded_file($image_url,$path);
		//echo"Saved";
		$sql="update report set image_url='$path' where rep_id=$auto_id";
		$query=mysql_query($sql);
		if($query)
		{
			echo"Sent";
		}
		else
		{
			echo"Error";
		}
	}
}




echo"
<form action='submit_report.php' method='post' enctype='multipart/form-data'>
<table id='a1'>
<tr><td><b>Date </b></td><td><input type='date' name='date' required></td></tr>
<tr><td><b>Upload Reports</b></td><td><input type='file' name='report' required></td></tr>
<tr><td><textarea name='text'></textarea></td></tr>

<tr><td><input type='submit' name='submit' value='Submit'></td></tr>
</table>
</form>
";
echo"</div></div></div>";
include("footer.php");
?>
</body>
</html>