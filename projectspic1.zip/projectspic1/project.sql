-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2017 at 08:33 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_app`
--

CREATE TABLE IF NOT EXISTS `book_app` (
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pat_id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_app`
--

INSERT INTO `book_app` (`app_id`, `user_id`, `pat_id`, `date`, `time`, `location`) VALUES
(1, 4, 4, '2017-07-27', '10:40', 'chd'),
(2, 4, 4, '2017-07-27', '10:00', 'chd'),
(3, 6, 6, '2017-07-29', '9:40', 'chd'),
(4, 6, 6, '2017-07-29', '9:00', 'chd');

-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE IF NOT EXISTS `center` (
  `cen_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `center`
--

INSERT INTO `center` (`cen_id`, `name`, `address`, `number`) VALUES
(2, 'abcd', '16hiw jhdk', '8922782383'),
(3, 'abcd', '16hiw jhdk', '8922782383'),
(5, 'ab', '1234 abcd', '123'),
(7, 'abcd', '1234', '34567890'),
(10, 'nk', 'rser', 'wtr5t'),
(11, 'fhh', 'fg', 'cbf');

-- --------------------------------------------------------

--
-- Table structure for table `checkup_time`
--

CREATE TABLE IF NOT EXISTS `checkup_time` (
  `user_id` int(11) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkup_time`
--

INSERT INTO `checkup_time` (`user_id`, `time`) VALUES
(6, '10'),
(10, '15');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `contact_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `query` varchar(100) NOT NULL,
  `review` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `name`, `email`, `query`, `review`) VALUES
(1, 'abcd', 'abcd', 'abcd', 'abcd');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `doctor` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `image_url` varchar(100) NOT NULL,
  `sec_ques` varchar(1000) NOT NULL,
  `sec_ans` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`user_id`, `fname`, `lname`, `dob`, `gender`, `number`, `email`, `password`, `doctor`, `address`, `city`, `state`, `pin`, `image_url`, `sec_ques`, `sec_ans`) VALUES
(1, 'kjhjk', 'hjuhk', '1999-03-21', 'female', '281098`', 'hdebjw', 'abcd', 'eesha Â ', 'h81jsijw', 'ueioii', 'iugu23', '678267', '', '', ''),
(2, 'jkj', 'ilik', '2000-12-12', 'male', '821u8', 'hdjqw', 'spic', 'eesha Â ', 'gshsqkw', 'ijidwe', 'ideiw', '273', 'patimage/2.png', '', ''),
(3, 'abcd', 'abcd', '2017-07-21', 'female', '5675', 'hgh78', 'spic', 'eesha Â ', 'gyg86', 'hgjh', 'hgj', '7889', 'patimage/3.jpg', '', ''),
(4, 'ab', 'ab', '2017-07-12', 'male', 'ab', 'ab', 'sa', 'eesha Â ', 'ab', 'ab', 'ab', 'ab', 'patimage/4.jpg', 'aaa', 'aaa'),
(5, 'ab', 'ab', '2017-07-21', 'male', 'ab', 'ab', 'ab', 'eesha Â ', 'ab', 'ab', 'ab', 'ab', 'patimage/5.jpg', '', ''),
(6, 'ab', 'ab', '2017-07-21', 'male', 'AB', 'AB', 'ab', 'eesha Â ', 'ab', 'ab', 'ab', 'ab', 'patimage/6.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `rep_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image_url` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`rep_id`, `user_id`, `date`, `title`, `image_url`) VALUES
(1, 3, '2017-07-12', 'abcd', 'report/3.1.jpg'),
(2, 3, '2017-07-02', 'xyz', 'report/3.2.jpg'),
(3, 3, '2017-07-25', 'yay', 'report/3.3.jpg'),
(4, 3, '2017-07-10', 'spic', 'report/3.4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `user_id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `from_time` varchar(100) NOT NULL,
  `to_time` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `sch_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`user_id`, `date`, `from_time`, `to_time`, `location`, `sch_id`) VALUES
(0, '2017-07-12', '5', '', 'abcd', 1),
(0, '2017-07-10', '', '', '--Select the center--', 2),
(0, '2017-07-10', '', '', '--Select the center--', 3),
(0, '2017-07-10', '', '', '--Select the center--', 4),
(0, '2017-07-27', '--From--', '--To--', '--Select the center--', 5),
(6, '2017-07-21', '--From--', '--To--', 'ab', 13),
(4, '2017-07-27', '9', '13', 'chd', 14),
(4, '2017-07-29', '8', '12', 'chd', 15);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gen` varchar(10) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `qual` varchar(100) NOT NULL,
  `spec` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin` varchar(11) NOT NULL,
  `image_url` varchar(100) NOT NULL,
  `sec_ques` varchar(1000) NOT NULL,
  `sec_ans` varchar(100) NOT NULL,
  `checkup_time` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fname`, `lname`, `email`, `password`, `gen`, `dob`, `number`, `qual`, `spec`, `address`, `city`, `state`, `pin`, `image_url`, `sec_ques`, `sec_ans`, `checkup_time`) VALUES
(4, 'eesha', 'jindal', 'eesha_97@yahoo.com', 'abcd', 'female', '1997-01-15', '1234567890', 'aff', 'saf', 'ewfewfe', 'fewdf', 'eqw', '123', '', '', '', '20'),
(5, '', '', '', '', '', '0000-00-00', '1234567890', '', '', '', '', '', '0', '', '', '', ''),
(8, 'abcd', 'abcd', 'abcd', 'spic', 'female', '2017-07-21', '78676', 'B.H.M.S', 'Addiction Psychiatry', 'g2h121', 'jhhj', 'hjjhi', '27876', 'docimage/8.jpg', '', '', ''),
(9, 'ab', 'ab', 'ab', 'ab', 'male', '2017-03-21', 'ab', 'B.D.S', 'A.R.R.D', 'ab', 'aba', 'ab', 'ab', 'docimage/9.jpg', '', '', ''),
(10, 'ab', 'ab', 'ab', 'ab', 'male', '2017-07-20', 'ab', 'B.D.S', 'A.R.R.D', 'ab', 'ab', 'ab', 'ab', 'docimage/10.jpg', '', '', '10'),
(11, 'aa', 'bb', 'abc@gmail.com', 'abc123', 'female', '2017-08-21', '8765432567', 'B.D.S', 'Endocrinology, Diabetes & M.I.M', 'jykjkyk', 'kjhkj', 'khkhkh', 'hkhh', '', 'What was your first pets name?', 'nnn', ''),
(12, 'gg', 'gg', 'gg', 'aa', 'male', '2017-07-12', '9876', 'M.B.B.S', 'C.D.I.M', 'jjj', 'jjj', 'jjj', 'jjj', 'docimage/12.jpg', 'Which was your first car?', 'hhh', '10'),
(13, 'gg', 'gg', 'gg', 'g', 'male', '2017-07-12', '9876', 'M.B.B.S', 'C.D.I.M', 'jjj', 'jjj', 'jjj', 'jjj', 'docimage/13.jpg', 'Which was your first car?', 'hhh', '10'),
(14, 'ab', 'ab', 'ab', 'abcd', 'male', '2017-07-21', '5678', 'B.D.S', 'A.R.R.D', '#1303-P Sector 21', 'Panchkula', 'Haryana', '134116', 'docimage/14.jpg', 'What was your first pet name?', 'ab', '15'),
(15, 'ab', 'ab', 'ab', 'ab', 'male', '2017-07-17', '6789', 'B.D.S', 'A.R.R.D', '#1303-P Sector 21', 'Panchkula', 'Haryana', '134116', 'docimage/15.jpg', 'What was your first pet name?', 'a', '20'),
(16, 'ab', 'ab', 'ab', 'ab', 'male', '2017-07-17', '6789', 'B.D.S', 'A.R.R.D', '#1303-P Sector 21', 'Panchkula', 'Haryana', '134116', 'docimage/16.jpg', 'What was your first pet name?', 'a', '20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_app`
--
ALTER TABLE `book_app`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `center`
--
ALTER TABLE `center`
  ADD PRIMARY KEY (`cen_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`rep_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`sch_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_app`
--
ALTER TABLE `book_app`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `center`
--
ALTER TABLE `center`
  MODIFY `cen_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `rep_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `sch_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
