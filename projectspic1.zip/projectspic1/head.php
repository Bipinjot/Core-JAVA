<div class='row'>
<div class='col-sm-2 head'>
<img src='images/icon.jpg' style='margin-top:10px; width:100px; height:100px; '  >


</div> <!--end of col12-->

<div class='col-sm-8 head'>
<div class='h1' style='padding-top:25px;'>Aarogya Heart Foundation </div>
<!--<h1 style='padding-top:15px; font-size:350%; color:rgb(150, 0, 0);'> Aarogya Heart Foundation </h1> -->
</div>


<div class='col-sm-2 head'>
<p style='padding-top:60px; color:rgb(150, 0, 0);'>Sign Up to Book an appointment</p>
</div>
</div>
<br/>
 <!--end of row-->