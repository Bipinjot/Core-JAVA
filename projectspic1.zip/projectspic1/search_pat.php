<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>

</style>
</head>
<body>
<?php

include("head.php");
include("doc_menu.php");
include("doc_side.php");
echo"
<div class='col-md-9'>

";

if(isset($_POST['search']))
{
	$name=$_POST['name'];
	
	$sql="select * from patient where fname='$name'";
	$query=mysql_query($sql);
	$row_data=mysql_fetch_row($query);
	$row_count=mysql_num_rows($query);
	if($row_count>0)
	{
	echo"<table id='a1' >
	<tr><td colspan='2'><img src='$row_data[13]'/></td></tr>
	<tr><td>Patient Id</td><td>$row_data[0]</td></tr>
	<tr><td>First Name</td><td>$row_data[1]</td></tr>
	<tr><td>Last Name</td><td>$row_data[2]</td></tr>
	<tr><td>Consultant Doctor</td><td>$row_data[8]</td></tr>
	<tr><td>D.O.B.</td><td>$row_data[3]</td></tr>
	<tr><td>Gender</td><td>$row_data[4]</td></tr>
	<tr><td>Contact Number</td><td>$row_data[5]</td></tr>
	<tr><td>Email</td><td>$row_data[6]</td></tr>
	<tr><td>Address</td><td>$row_data[9]</td></tr>
	<tr><td>City</td><td>$row_data[10]</td></tr>
	<tr><td>State</td><td>$row_data[11]</td></tr>
	<tr><td>Pin</td><td>$row_data[12]</td></tr>
	</table>";
	}
	else{
		echo"Not Found";
	}
	
}

else
{
echo"
<form action='search_pat.php' method='post'>
<table id='a1'>
<tr><td>Patient Name </td>
<td><input type='text' name='name'></td></tr>
<tr><td><input type='submit' name='search' value='Search'></td></tr>

</table></form>";
}

echo"</div></div></div>";
include("footer.php");

?>
</body>
</html>