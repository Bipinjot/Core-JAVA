<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
a:link
{
	text-decoration:none;
	color:black;
}

#a1 td
{
	padding:10px;
}
</style>
</head>
<body>
<?php

include("head.php");
include("doc_menu.php");
include("doc_side.php");
echo"
<div class='col-md-9'>

";

if(isset($_POST['set']))
		{	
		
		$date=$_POST['date'];
		$from=$_POST['from'];
		$to=$_POST['to'];
		$center=$_POST['center'];
		
$sql="insert into schedule(user_id,date,from_time,to_time,location) values($user_id,'$date','$from','$to','$center')";		
		
$query=mysql_query($sql);
if ($query)
{
	echo"<table id='a1'>
	<td>Saved</td>
	<td><a href='view_schedule.php'><input type='button' value='View Schedule'></a>	
	</td></tr></table>";
}	

		}
echo"
<form action='schedule.php' method='post'>
<table id='a1'>
<tr><td>Date </td>
<td><input type='date' name='date' required></td></tr>

<tr><td>Time</td>
<td><select name='from'>
<option selected>--From--</option>";

for ($i = 8; $i <= 19; $i++){
  for ($j =0; $j <= 45; $j+=15){
	  if ($j==0){
		  echo"<option>$i:00</option>";
	  }
	  else{
    //inside the inner loop
	  echo"<option>$i:$j</option>";}
  }
  //inside the outer loop
}
//outside the outer loop



echo"</select></td>
<td><select name='to'>
<option selected>--To--</option>";
for ($i = 8; $i <= 19; $i++){
  for ($j = 00; $j <= 45; $j+=15){
    //inside the inner loop
    echo"<option>$i : $j</option>";
  }
  //inside the outer loop
}
//outside the outer loop

echo"</select></td></tr>

<tr><td>Center</td>
<td><select name='center'>
<option selected>--Select the center--</option>";

$sql1="select * from center";
$query1=mysql_query($sql1);
while($row_data1=mysql_fetch_array($query1))
{
echo"<option>$row_data1[1]</option>";
}
echo"
</select></td>
<td><a href='new_center.php'><input type='button' value='Add New'></a></td></tr>


<tr><td><input type='submit' name='set' value='Set'></td>
<td><a href='schedule.php'><input type='button' value='Cancel'></a></td></tr>
</table>
</form>
";

echo"</div></div></div>";
include("footer.php");

?>

</body>
</html>
