<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
th
{
	text-align:center;
}
</style>
</head>
<body>
<?php

include("head.php");
include("pat_menu.php");
include("pat_side.php");
echo"<div class='col-md-1'></div>
<div class='col-md-8'>

";

if(isset($_POST['view']))
{
	$date=$_POST['date'];
	$sql="select * from schedule where date='$date'";
	$query=mysql_query($sql);
	
	$row_count=mysql_num_rows($query);
	if($row_count>0)
	{
	echo "<table border=1 width=50%>
	<tr><th rowspan='2'>Doctor</th><th rowspan='2'>Date</th><th rowspan='2'>Center</th><th colspan='2'>Time</th></tr>
	<tr><th>To</th><th>From</th></tr>";
	
	while($row_data=mysql_fetch_array($query))
	{
		$sql2="select* from user where user_id=$row_data[0]";
		$query2=mysql_query($sql2);
		$row_data2=mysql_fetch_row($query2);
		echo"<tr>	
<td>$row_data2[1] $row_data2[2]</td>		
	<td>$row_data[1]</td>
	<td>$row_data[4]</td>
	<td>$row_data[2]</td>
	<td>$row_data[3]</td>
	</tr>";
	}
	echo "</table>";
	
	
}

else{
	echo"Schedule not set for this date";
}
}
//if(isset($_POST['go']))
//{
	//$doc=$_POST['doc'];
	//$sql="select * from user where ='$doc'";
	//$query=mysql_query($sql);
	
	else{
echo"<form action='pat_view_schedule.php' method='post'>
<table id='a1'>
<tr><td>Enter Date</td>
<td><input type='date' name='date' required></td></tr>
<tr><td><input type='submit' name='view' value='View'></td></tr>
</table></form>
	";}
//}

/*else{
	echo"<form action='view_schedule.php' method='post'>
<table id='a1'>
<tr><td>Enter Doctor's Name</td>
<td><input type='text' name='doc' required></td></tr>
<tr><td><input type='submit' name='go' value='View'></td></tr>
</table></form>";
	
}*/

echo"</div></div></div>";
include("footer.php");

?>
</body>
</html>
