<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#a2 th
{
	text-align:center;
}
#a2 td
{
padding:50px;	
}
</style>
</head>
<body>
<?php
include("head.php");
include("doc_menu.php");
include("doc_side.php");
echo"<div class='col-md-9'>";

if(isset($_POST['view']))
{
	$pat=$_POST['pat'];
	
	$sql="select * from report where user_id=$pat";
	$query=mysql_query($sql);
	$row_count=mysql_num_rows($query);
	if($row_count>0)
	{
		echo"Patient's Id: $pat<br/>
		<table id='a2' >
		<tr><th>Date</th><th>Reports</th><th>Description</th></tr>
		";
		
		while($row_data=mysql_fetch_array($query))
		{
			echo"<tr>
			<td>$row_data[2]</td>
			<td><img src='$row_data[4]' width='100px' height='100px'></td>
			<td>$row_data[3]</td>
			</tr>";
		}
	}
	else
	{
		echo"No reports found for the patient.";
	}
	
	
}



else
{
echo"<form action='view_report.php' method='post'>
<table id='a1'>
<tr><td>Enter Patient's Id</td>
<td><input type='text' name='pat'></td></tr>
<tr><td><input type='submit' name='view' value='View Reports'></td></tr>

</table></form>
";
}
echo"</div></div></div>";
include("footer.php");
?>
</body>
</html>