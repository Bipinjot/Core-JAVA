<!--<div class='row'>
<div class='col-md-12 menu'>
<table width=80%>
<tr>
<td style="padding-left:20px";><a href='doc_profile.php'>Profile </a></td>
<td><a href='schedule.php'>Set Schedule </a></td>
<td><a href='view_schedule.php'>View Schedule</a></td>
<td><a href='checkup_time.php'> Set checkup time</a></td>
<td><a href='search_pat.php'>Search Patient</a></td>
<td><a href='view_report.php'>View Reports</a></td>
<td><a href='logout.php'> Logout </a></td>
<!-- <td><a href='demo.php'>Home </a></td> --
</tr>
</table>
</div> <!--end of col12--
</div> <!--end of row-->


<?php
echo"<nav class='navbar navbar-default'>
  
    
    <ul class='nav navbar-nav'>
      <li><a href='doc_profile.php'>Profile</a></li>
      <li><a href='view_schedule.php'>View Schedule</a></li>
      <li><a href='checkup_time.php'>Set Checkup Time</a></li>
	  <li><a href='view_report.php'>View Reports</a></li>
	  <li><a href='viewapp.php'>View Appointments</a></li>
	  <li><a href='query.php'>View Queries</a></li>
    </ul>
    <ul class='nav navbar-nav navbar-right' style='padding-right:50px;'>
	
     
      <li><a href='search_pat.php'> Search Patient</a></li>
	  <li><a href='logout.php'>Logout</a></li>
    </ul>
  
</nav>
  

";
?>