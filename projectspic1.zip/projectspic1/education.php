




<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<?php
include ("script.php");
?>
</head>
<body>
<div class='container-fluid'>
<?php
include("head.php");
include("menu.php");
echo"
<div class='row'>
<div class='col-md-12 edu'>
Patient Education
</div> <!--end of col12-->
</div> <!--end of row-->
";

include("footer.php");
?>
</div>
</body>
</html>