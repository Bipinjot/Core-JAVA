<?php
session_start();
include("connection.php");
if(isset($_REQUEST['case']))
{
	$case=$_REQUEST['case'];
	$_SESSION['case']=$case;
}
else if(isset($_SESSION['case']))
{
	$case=$_SESSION['case'];
	
}
//echo "case :".$case;
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#e1 td
{
	padding:10px;
}
</style>

<meta charset="utf-8">
<title>Bootstrap jQuery Validate form : twitterbootstrap.org</title>
<meta name="viewport" content="width=device-width">
<link href="style.css" rel="stylesheet">

</head>

<body>
<?php
include("head.php");
include("menu.php");
//include("pat_menu.php");

echo"
<div class='container'>
<div class='panel heading'>FORGET PASSWORD</div>
<div class='panel body'>";

if(isset($_REQUEST['act']))
{
	//$sec_ans=$_POST['ans'];
	//$id=$_POST['id'];
	$act=$_REQUEST['act'];
	switch($act)
	{
		case 1:
		echo"
		
		<form method='post' action='forget_pat.php?act=2'>
		<table id='e1'>
		<tr><td>Enter new password</td><td><input type='password' class='input-xlarge' name='password' id='password'></td></tr>
		<tr><td>Confirm password</td><td><input type='password' class='input-xlarge' name='confirm_password' id='password'></td></tr>
		<tr><td><input type='submit' value='update'></td></tr>
		</table>
		</form>
		";
		break;
		
		
		case 2:
		
		
		$id=$_REQUEST['id'];
		$pwd=$_POST['password'];
		if($case==1)
		$sql="update patient set password='$pwd' where user_id='$id'";
		else
		$sql="update user set password='$pwd' where user_id='$id'";
			
		$query=mysql_query($sql);
		if($query)
		{
		echo "Your password has been changed<br/>
			 Click here to go to <a href='index.php'>Home</a>";
		}
		else
		{
		echo "not updated";	
	    }
				
		break;
		
		
		//case 3:
		//$sec_ans=$_POST('ans');
		
		//break;
	
		
	}
}

/*
if(isset($_POST['submit']))
{
	$id=$_POST['id'];
		$pwd=$_POST['password'];
		$sql="update patient set password='$pwd' where user_id='$id'";
		$query=mysql_query($sql);
		if($query)
		{
		echo "Your password has been changed<br/>
			 Click here to go to <a href='index.php'>Home</a>";
		}
		else
		{
		echo "not updated";	
	    }
	
}
*/
else if(isset($_POST['submit_ans']))
{
	
	$id=$_REQUEST['id'];
	$sec_ans=$_POST['ans'];
	if($case==1)
	$sql="select sec_ans from patient where user_id='$id'";
	else
	$sql="select sec_ans from user where user_id='$id'";
		
	
		$query=mysql_query($sql);
		$row_data=mysql_fetch_row($query);
		if($sec_ans==$row_data[0])
		{



      echo "<form id='registration-form' class='form-horizontal' action='forget.php?act=2&id=$id' method='post'>
       
			<table id='e1' width=50%>
			<tr><td><label class='control-label' for='name'>Password</label></td><td> <input type='password' class='input-xlarge' name='password' id='password'></td></tr>
			
			<tr><td><label class='control-label' for='name'>Confirm Password</label></td><td><input type='password' class='input-xlarge' name='confirm_password' id='password'></td></tr>
			
			
			<tr><td><input type='submit' class='input-xlarge' name='submit'></td><td><input type='reset' class='input-xlarge' name='reset'></td></tr>
			
			</table>
			
			</form>";	


	}
	
	
		else
		{
		echo "Wrong submission</br>
			 <a href='forget.php?id=$id'>back</a>";
		}
		
}

else if (isset($_POST['save2']) ||isset($_REQUEST['id']))
{
	if(isset($_POST['id']))
	$id=$_POST['id'];
	else
	$id=$_REQUEST['id'];
	
	if($case==1)
	$sql="select sec_ques from patient where user_id='$id'";
	else
	$sql="select sec_ques from user where user_id='$id'";
	
	$query=mysql_query($sql);
	$row_data=mysql_fetch_row($query);
	$row_count=mysql_num_rows($query);
	if($row_count>0)
	{
		echo
	"
		<form method='post' action='forget.php?id=$id' method='post'>
<input type='hidden' value='$id' name='id'/>
		<table border=1 id='e1'>
	
	<tr><td>Security Question</td><td>$row_data[0]</td></tr>
		<tr><td>Security Answer</td><td><input type='text' name='ans'></td></tr>
		<tr><td>Respond</td><td><input type='submit' name='submit_ans' value='SUBMIT'></td></tr>
		</table>
		</form>
	
	
	";	
	
	}
	else
	{
		echo "Patient id does not exsist</br><a href='forget.php'>Go back</a>";
	}
}
else
{
	echo 
	"
	<form action='forget.php' method='post'>
	<table>
	<tr><td>Enter your id</td><td><input type='text' name='id' placeholder='enter your id'/></td></tr>
	<tr><td>Enter</td><td><input type='submit' name='save2' value='SUBMIT'/></td></tr>
	</table>
	</form>
	";
	
	
}	
echo"</div></div>";	
?> 




					<script src="dist/assets/js/jquery-1.7.1.min.js"></script> 

					<script src="dist/assets/js/jquery.validate.js"></script> 

					<script src="dist/script.js"></script> 
					<script>
							addEventListener('load', prettyPrint, false);
							$(document).ready(function(){
							$('pre').addClass('prettyprint linenums');
								});
							</script> 






<?php
include("footer.php");
?>


</body>
</html>