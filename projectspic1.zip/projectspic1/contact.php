<?php

include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#e1 td
{
	padding:10px;
}
</style>
<meta charset="utf-8">
<title>Bootstrap jQuery Validate form : twitterbootstrap.org</title>
<meta name="viewport" content="width=device-width">
<link href="style.css" rel="stylesheet">
</head>

<body>
<?php
include("head.php");
include("menu.php");
//include("pat_menu.php");
?>
<div class='container'>
<?php
echo"
<div class='panel heading'>CONTACT US</div>
<div class='panel body'>";

if(isset($_POST['save']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$query=$_POST['query'];
	$review=$_POST['review'];
	$sql="insert into contact (name,email,query,review) values ('$name','$email','$query','$review')";
	$query=mysql_query($sql);
	if($query)
	{
		echo 
		"
		Your response has been recorded</br>
		Click here to go to<a href='index.php'>Home</a>
		";
	}
	else
	{
		echo
		"
		kindly respond again
		";
	}
}

else
{
		 echo"
		 <form action='contact.php' method='post'>
		 <table id='e1'>
		 <tr><td>Enter your name</td><td><input type='text' name='name' ></td></tr>
		 <tr><td>Enter your e-mail id</td><td><input type='text' class='input-xlarge' name='email' id='email'></td></tr>
		 <tr><td>Query</td><td><textarea name='query'></textarea></td></tr>
		 <tr><td>Review</td><td><textarea name='review'></textarea></td></tr>
		 <tr><td>Submit</td><td><input type='submit' name='save' value='Click here'></td></tr>
		 </table>
		 </form>
	";
	
}
	
	
	echo"</div>";
	?>
	
	<script src="dist/assets/js/jquery-1.7.1.min.js"></script> 

					<script src="dist/assets/js/jquery.validate.js"></script> 

					<script src="dist/script.js"></script> 
					<script>
							addEventListener('load', prettyPrint, false);
							$(document).ready(function(){
							$('pre').addClass('prettyprint linenums');
								});
							</script> 

	<?php
include("footer.php");
 ?>
</div>
</body>
</html>