<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
</head>
<body>
<?php
include("head.php");
include("menu.php");

echo "profile<br/>";

echo"<a href='change_image.php'>Change Profile Picture</a><br/>
<a href='schedule.php'>Set Schedule</a><br/>
<a href='view_schedule.php'>View Schedule</a><br/>";
echo"<a href='logout.php'>Logout</a><br/>";
include("footer.php");
?>
</body>
