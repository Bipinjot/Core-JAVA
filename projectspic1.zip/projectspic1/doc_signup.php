<?php
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");

?>
<style>
#a1 td{
	padding:8px;
}
</style>
</head>
<body>
<?php

echo"<div class='container'>";

include ("head.php");
	include ("menu.php");
	
	echo "<div class='row'>
	<div class='col-md-12'>
	<div class='panel'>
	<div class='panel-body'>";

	if(isset($_POST['submit']))
		{
			
			$f_name=$_POST['fname'];
		$l_name=$_POST['lname'];
		$email=$_POST['email'];
		$password=$_POST ['pwd'];
		$gen=$_POST['gen'];
		$dob=$_POST['dob'];
		$number=$_POST['number'];
		$qual=$_POST['qual'];
		$spec=$_POST['spec'];
		$add=$_POST['address'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$pin=$_POST['pin'];
		$sec_ques=$_POST['ques'];
		$sec_ans=$_POST['ans'];
		
		$image=$_FILES['image'];
		$image_name=$image['name'];
		$image_url=$image['tmp_name'];
		$checkup=$_POST['checkup'];
			
	$sql="insert into user(fname,lname,email,password,gen,dob,number,qual,spec,address,city,state,pin,sec_ques,sec_ans,checkup_time) values('$f_name','$l_name','$email','$password','$gen','$dob','$number','$qual','$spec','$add','$city','$state','$pin','$sec_ques','$sec_ans','$checkup')";
	$query=mysql_query($sql);
	if ($query)
		
		{
			$auto_id=mysql_insert_id();
			$image_info=explode(".",$image_name);
			$len=count($image_info);
			$path="docimage/$auto_id".".".$image_info[$len-1];
			move_uploaded_file($image_url,$path);
			// echo"saved<br> Doctor's Id=$auto_id";
			$sql="update user set image_url='$path' where user_id=$auto_id" ;
			$query=mysql_query($sql);
			if($query)
			{
				echo "saved<br/> Doctor's Id=$auto_id";
				/*
				$sql1="insert into checkup_time(user_id,time) values($auto_id,'$checkup')";
				$query1=mysql_query($sql1);
				if($query1)
				{
				echo"saved<br> Doctor's Id=$auto_id";
				}*/
			}
			else{
				echo"error";
				
			}
		}
	else
	{
		echo"error<br>$sql";
	}
	
		}
	echo"
	<h2> SignUp</h2>
	
	<form method='post' action='doc_signup.php' enctype='multipart/form-data' id='myform'>
	<table id='a1'>
	<tr><td><b>Firstname </b></td>
	<td> <input type='text' placeholder='Enter Firstname' name='fname' required'></td></tr>
	
	<tr><td><b>Lastname</b></td>
			  <td><input type='text' placeholder='Enter Lastname' name='lname' required></td></tr>
	
	<tr><td><b>Email</b></td>
			  <td><input type='text'  placeholder='Enter Email' name='email'>
				<span class='email'>Please fill correct email id**</span></td></tr>
				
	<tr><td><b>Password</b></td>
			  <td><input type='password'  placeholder='Enter password' name='pwd'/>
				<span class='pwd'>*</span></td>	

<tr><td><b>Confirm Password</b></td>
<td><input type='password' placeholder='Repeat Password' name='con_pwd' required></td></tr>				

<tr><td><b>Security Question</b></td><td><select name='ques' required>
<option>What was your first pet name?</option>
<option>Which was your first car?</option>
<option>What is your favourite holiday destination?</option>
<option>What was your first teacher name?</option>
<option>Which is your favourite novel?</option>
</select></td></tr>
	
	
<tr><td><b>Answer</b></td><td><input type='text' name='ans' required></td></tr>	

	<tr><td><b>Gender</b></td>
	<td><input type='radio' name='gen' value='male' checked>Male
					<input type='radio' name='gen' value='female'>Female</td></tr>
					
	<tr><td><b>D.O.B</b></td><td>
			  
			  <input type='date' name='dob' required>	
			  
</td></tr>
<tr><td><b>Mobile No.</b></td>
			  <td><input type='text' placeholder='Enter Mobile Number' name='number' maxlength='10' required></td></tr>
			
			<tr><td><b>Qualification</b></td>
<td><select name='qual' required>
				<option selected>--SELECT ONE--</option>
				<option>B.D.S</option>
				<option>B.H.M.S</option>
				<option>B.P.T</option>
				<option>B.U.M.S</option>
				<option>M.B.B.S</option>
				<option>MD</option>
				<option>MS</option>
				<option>MDS</option>
			</select></td></tr>
			
			<tr><td><b>Speciality</b></td>
			<td><select name='spec' required >
			  <option selected>--SELECT ONE--</option>
				<option>A.R.R.D</option>
				<option>Addiction Psychiatry </option>
				<option>A.M.P</option>
				<option>Allergy & Immunology</option>
				<option>Anesthesiology</option>
				<option>C.R.R.D</option>
				<option>C.D.I.M</option>
				<option>C.P- A&C</option>
				<option>Dermatology</option>
				<option>Dermatopathology </option>
				<option>Endocrinology, Diabetes & M.I.M</option>
				<option>Endovascular Surgical Neuroradiology </option>
				<option>Gastroenterology Internal Medicine</option>
				<option>Geriatric Medicine Family Medicine</option>
			</select></td></tr>
			
			
			<tr><td><b>Set Checkup Time</b></td><td><select name='checkup' required>
			<option>10</option>
			<option>15</option>
			<option>20</option>
			<option>30</option>
			</select></td></tr>
			
			<tr><td><b>Address</b></td>
			  <td><input type='text' placeholder='Address' name='address' required></td></tr>
			
			<tr><td><b>City</b></td>
			  <td><input type='text' placeholder='Enter City' name='city' required> </td></tr>
	
	<tr><td><b>State</b></td>
			  <td><input type='text' placeholder='Enter State' name='state' required>  </td></tr> 
			
			<tr><td><b>Pincode</b></td>
			  <td><input type='text' placeholder='Enter Pincode' name='pin' required></td></tr>  
			
			<tr><td><b>Upload Image</b></td>
	<td><input type='file' name='image' required> </td>
			
			
		<tr><td colspan=4><input type='submit' value='Submit' name='submit'></td></tr>
		
	</table>
	</form>
";
	

echo"</div></div></div></div></div>";
include("footer.php");

?>


</body>
</html>