<?php
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
#a1 td{
	padding:8px;
}
</style>
</head>
<body>
<?php

echo"<div class='container'>";

include ("head.php");
	include ("menu.php");
	
	echo "<div class='row'>
	<div class='col-md-12'>
	<div class='panel'>
	<div class='panel-body'>";

	if(isset($_POST['submit']))
		{
			
			$f_name=$_POST['fname'];
		$l_name=$_POST['lname'];
		$dob=$_POST['dob'];
		$gen=$_POST['gen'];
		$number=$_POST['number'];
		$email=$_POST['email'];
		$password=$_POST ['pwd'];	
		$doc=$_POST['doc'];
		$add=$_POST['address'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$pin=$_POST['pin'];
		$sec_ques=$_POST['ques'];
		$sec_ans=$_POST['ans'];
		$image=$_FILES['image'];
		$image_name=$image['name'];
		$image_url=$image['tmp_name'];
	
	$sql="insert into patient(fname,lname,dob,gender,number,email,password,doctor,address,city,state,pin,sec_ques,sec_ans) values('$f_name','$l_name','$dob','$gen','$number','$email','$password','$doc','$add','$city','$state','$pin','$sec_ques','$sec_ans')";
	$query=mysql_query($sql);
	if ($query)
		
		{
			$auto_id=mysql_insert_id();
			$image_info=explode(".",$image_name);
			$len=count($image_info);
			$path="patimage/$auto_id".".".$image_info[$len-1];
			move_uploaded_file($image_url,$path);
			// echo"saved<br> Doctor's Id=$auto_id";
			$sql1="update patient set image_url='$path' where user_id=$auto_id" ;
			$query1=mysql_query($sql1);
			if($query1)
			{
				echo"Saved<br> Patient Id=$auto_id";
			}
			else{
				echo"error";
				
			}
		}
	else
	{
		echo"error<br>$sql";
	}
	
		}
	echo"
	<h2>SignUp</h2>
	
	<form method='post' action='pat_signup.php' enctype='multipart/form-data'>
	<table id='a1'>
	<tr><td><b>Firstname </b></td>
	<td> <input type='text' placeholder='Enter Firstname' name='fname' required></td></tr>
	
	<tr><td><b>Lastname</b></td>
			  <td><input type='text' placeholder='Enter Lastname' name='lname' required></td></tr>
			  
			  <tr><td><b>D.O.B</b></td><td>
			  <input type='date' name='dob' required></td></tr>
	
		<tr><td><b>Gender</b></td>
	<td><input type='radio' name='gen' value='male' checked>Male
					<input type='radio' name='gen' value='female'>Female</td></tr>
					
	<tr><td><b>Mobile No.</b></td>
			  <td><input type='text' placeholder='Enter Mobile Number' name='number' maxlength='10' required></td></tr>				
	
	<tr><td><b>Email</b></td>
			  <td><input type='text'  placeholder='Enter Email' name='email'>
				<span class='email'>Please fill correct email id**</span></td></tr>
				
	<tr><td><b>Password</b></td>
			  <td><input type='password'  placeholder='Enter password' name='pwd'/>
				<span class='pwd'>*</span></td>	

<tr><td><b>Repeat Password</b></td>
<td><input type='password' placeholder='Repeat Password' name='pwd-re' required></td></tr>

<tr><td><b>Security Question</b></td><td><select name='ques' required>
<option>What was your first pet name?</option>
<option>Which was your first car?</option>
<option>What is your favourite holiday destination?</option>
<option>What was your first teacher name?</option>
<option>Which is your favourite novel?</option>
</select></td></tr>
	
	
<tr><td><b>Answer</b></td><td><input type='text' name='ans' required></td></tr>	";
			
	
echo"
<tr><td><b>Consultant Doctor </b></td>
<td><select name='doc'>
<option selected>--Select your doctor--</option>";

$sql1="select * from user";
$query1=mysql_query($sql1);
while($row_data1=mysql_fetch_array($query1))
{
echo"<option>$row_data1[1] &nbsp; $row_data[2]</option>";
}
echo"
</select>
</td></tr>
";
			
			
		echo"	
			<tr><td><b>Address</b></td>
			  <td><input type='text' placeholder='Address' name='address' required></td></tr>
			
			<tr><td><b>City</b></td>
			  <td><input type='text' placeholder='Enter City' name='city' required> </td></tr>
	
	<tr><td><b>State</b></td>
			  <td><input type='text' placeholder='Enter State' name='state' required>  </td></tr> 
			
			<tr><td><b>Pincode</b></td>
			  <td><input type='text' placeholder='Enter Pincode' name='pin' required></td></tr>  
			
			<tr><td><b>Upload Image</b></td>
	<td><input type='file' name='image' required> </td>
			
			
		<tr><td colspan=4><input type='submit' value='Submit' name='submit'></td></tr>
		
	</table>
	</form>
";
	

echo"</div></div></div></div></div>";
include("footer.php");

?>


</body>
</html>