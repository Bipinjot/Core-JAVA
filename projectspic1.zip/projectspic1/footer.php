<!--<div class='row'>
		<div class='col-md-12 footer'>Footer
		</div>  <!--END OF col-md-12--
	</div>  <!--END OF ROW-->
	
	
	<div class='row'>
		<div class='col-md-12'>
		<div class='well well-md footer_temp'>
		<table width='90%'>
<tr><th>INFORMATION</th><th>WHY US</th><th>MY ACCOUNT</th><th>FOLLOW US</th></tr>
<tr><td>About us</td><td>Surgeries</td><td>Sign In</td><td>Facebook</td></tr>
<tr><td>Customer Service</td><td>Secure your future</td><td>View Details</td><td>Twitter</td></tr>
<tr><td>Settings</td><td>International Relations</td><td>My Account</td><td>RSS</td></tr>
<tr><td>Privacy Policy</td><td>Affiliates</td><td>Track My Doctor</td></tr>
<tr><td>Site Map</td><td>Group</td><td>Help</td></tr>
<tr><td>Search Terms</td></tr>
<tr><td>Advanced Search</td></tr>
<tr><td>OPD</td></tr>
<tr><td>Contact Us</td></tr>
</table>
<p>&copy; All Rights Reserved.
<br>
<br>
<center>2017</center></p>
		</div>
		</div>
		</div>