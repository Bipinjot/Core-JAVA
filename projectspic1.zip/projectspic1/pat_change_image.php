<?php
include("user_info.php");
include("connection.php");
?>
<html>
<head>
<?php
include("script.php");
?>
<style>
a:link
{
	text-decoration:none;
	color:black;
}

#a1 td
{
	padding:10px;
	text-align:center;
}
</style>
</head>
<body>
<?php

include("head.php");
include("pat_menu.php");
include("pat_side.php");
echo"
<div class='col-md-9'>

";



echo"<br>";





if(isset($_REQUEST['act']))
			{
			//echo "Edit & Delete";	
			$act=$_REQUEST['act'];
			//$empid=$_REQUEST['empid'];
				switch($act)
				{
					case 1:
					$sql="select image_url from patient where user_id=$user_id";
					//echo $sql;
					$query=mysql_query($sql);
					$row_data=mysql_fetch_row($query);
					$image_url=$row_data[0];
					
					
						$sql="delete from patient where user_id=$user_id";
						$query=mysql_query($sql);
						if($query)
						{
							unlink($image_url);
							
							echo "deleted";
						}
						else{
							echo "error<br/>$sql";
						}
					
						break;
					case 2: 
							$sql="select * from patient where user_id=$user_id";
							$query=mysql_query($sql);
							$row_data=mysql_fetch_row($query);
							//print_r($row_data);
							echo "
							<form action='pat_change_image.php?act=3' method='post' enctype='multipart/form-data'>
							<table id='a1'>";
							/*<tr><td>Empid</td><td> $empid<input type='hidden' name='empid' value='$empid'/></td></tr>
							
							<tr><td>Empname</td><td><input type='text' name='ename' value='$row_data[1]'/></td></tr>
							
							<tr><td>Empsalary</td><td><input type='text' name='esalary' value='$row_data[2]'/></td></tr>
							<tr><td>Empimage</td><td>*/
							echo"<input type='file' name='image'/></td></tr>
						
						<tr></td><input type='hidden' name='old_url' value='$row_data[13]'/></td></tr>
							
							<tr><td><input type='submit' value='Update'/></td><td>
							<a href='pat_change_image.php?id=$user_id'><input type='button' value='Cancel'></a>
							</td></tr>
							
							</table>
							</form>
							";
					
							
							break;
					case 3:
					//echo "update case<br/>";
					$old_url=$_POST['old_url'];
					echo "old_url=$old_url<br/>";
							$image=$_FILES['image'];
							$path1=$image['tmp_name'];
							$image_name=$image['name'];
							//echo "<hr/>image_name=$image_name";
							//echo "<hr/>";
							if($image_name!="")
							{
							$image_info=explode('.',$image_name);
							$len=count($image_info);
							$path2="patimage/$user_id".".".$image_info[$len-1];
							//echo $path2;
							}
							//echo "<br/>";
							//echo $empimage;
							
							//$empid=$_POST['empid'];
							//$empname=$_POST['ename'];
							//$empsalary=$_POST['esalary'];
							if($image_name!="")
							{
							$sql="update patient set image_url='$path2' where user_id=$user_id";
							}
							
							$query=mysql_query($sql);
							
							if($query)
							{

							if($image_name!="")

							{
								if($old_url!="")
								{
									unlink($old_url);
								}
								move_uploaded_file($path1,$path2);
							}						
					header("Location:pat_change_image.php?id=$user_id");

							}
							else{
								echo "error<br/>$sql";
							}
						
					break;
				}
			}
			


			
	else
	{		
echo"
<table id='a1'>
<tr><td><a href='pat_change_image.php?act=2'><input type='button' value='Edit'></a></td>";
//<td><a href='pat_change_image.php?act=1'><input type='button' value='Delete'></a></td></tr>
echo"</table>

";
	}

echo"</div></div></div>";
include("footer.php");

?>

</body>
</html>
